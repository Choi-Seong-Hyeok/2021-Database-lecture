create database IF NOT EXISTS UNIVERSITY;
USE UNIVERSITY;
alter database university default character set utf8mb4;

set foreign_key_checks = 0;   
drop table IF EXISTS 고객 cascade;     
drop table IF EXISTS 대리점 cascade;   
drop table IF EXISTS 제품모델 cascade;
drop table IF EXISTS 직원 cascade;
drop table IF EXISTS 렌탈정보 cascade;
set foreign_key_checks = 1;   
/*
	테이블 생성
*/
create table 대리점 (
    	대리점ID varchar(10) NOT NULL, 
    	대리점이름 varchar(10) NOT NULL, 
	대리점주소 varchar(100), 
	대리점전화번호 varchar(20),
    primary key (대리점ID));
    
create table 고객 (
    	고객ID varchar(10) NOT NULL, 
    	고객이름 varchar(10) NOT NULL, 
	고객주소 varchar(100), 
	고객연락처 varchar(20),
    primary key (고객ID));
create table 직원 (
    	직원ID varchar(10) NOT NULL, 
    	직원이름 varchar(10) NOT NULL, 
	직원주소 varchar(100), 
	직원연락처 varchar(20),
    대리점ID varchar(10),
	primary key (직원ID),
    FOREIGN KEY (대리점ID) REFERENCES 대리점(대리점ID) on delete cascade);
    
create table 제품모델 (
	대리점ID varchar(10) NOT NULL, 
	모델번호 varchar(10) NOT NULL, 
	모델종류 varchar(10) NOT NULL,
    출시년도 int, 
	소비전력 int,
    구입날짜 date,
    고객ID varchar(10),
    렌탈예정일 date,
    반납예정일 date,
	primary key (대리점ID,모델번호),
    FOREIGN KEY (대리점ID) REFERENCES 대리점 (대리점ID) on delete cascade,
    FOREIGN KEY (고객ID) REFERENCES 고객 (고객ID) on delete cascade,
    check(소비전력 >= 0));
    
 create table 렌탈정보(
	고객ID varchar(10) NOT NULL, 
	대리점ID varchar(10) NOT NULL,
	모델번호 varchar(10) NOT NULL,
	대출일 date,
	반납일 date,
	반납연체일수 int,
	primary key (고객ID,대리점ID,모델번호,대출일),
	FOREIGN KEY (고객ID) REFERENCES 고객 (고객ID)on delete cascade,
    FOREIGN KEY (대리점ID,모델번호) REFERENCES 제품모델 (대리점ID,모델번호) on delete cascade,
    check(반납연체일수 >= 0));
    
insert into 고객 
values('C001', 'PDN', '강동구 암사동', '010-3304-6302' );
insert into 고객
values('C002', 'KYS', '경기도 의왕시 삼동', '010-7323-3789');
insert into 고객
values('C003', 'YDJ', '관악구 신림동', '010-2628-7436');                                  
insert into 고객
values('C004', 'KSM', '강동구 명일동', '010-2299-7827');
insert into 고객
values('C005', 'PJH', '마포구 강인동', '010-3157-2501');                                  
insert into 고객
values('C006', 'HBC', '노원구 상계동', '010-2936-5427');                                  
insert into 고객
values('C007', 'KCY', '강동구 천호동', '010-7119-6732');                                  
insert into 고객
values('C008', 'PYS', '중랑구 상봉동', '010-2523-9738');                                  
insert into 고객
values('C009', 'KHJ', '강남구 대치동', '010-2255-8247');                                 
insert into 고객
values('C010', 'KDH', '강동구 명일동', '010-4516-9281');     

insert into 대리점
values('B001', '홍익대리점', '마포구 상수동', '02-320-1114');
insert into 대리점
values('B002', '성균관대리점', '종로구 혜화동', '02-760-0114');                                    
insert into 대리점                                    
values('B003', '한양대리점', '성동구 왕십리동', '02-2220-0114');

insert into 직원
values('E001', 'KMS', '광진구 자양동', '010-9502-1342', 'B001');
insert into 직원
values('E002', 'YKD', '강동구 상일동', '010-3422-1886', 'B001');                     
insert into 직원
values('E003', 'KHD', '마포구 서교동', '010-9872-8531', 'B002');                      
insert into 직원
values('E004', 'MKH', '마포구 상암동', '010-5261-2332', 'B002');                      
insert into 직원
values('E005', 'PSC', '성북구 안암동', '010-0934-1869', 'B003');                      
insert into 직원
values('E006', 'YSS', '강남구 개포동', '010-9515-8534', 'B003');                      


insert into 제품모델
values('B001','M001','세탁기','2019','1400','21/10/16','C001','2021/11/12','21/11/18');
insert into 제품모델
values('B001','M002','냉장고','2021','1200','20/10/10','C001','2021/11/12','21/11/24');
insert into 제품모델
values( 'B001','M003','오븐','2020','1700','20/01/26','C002','2021/11/13','21/11/20');
insert into 제품모델
values('B002','M004','세탁기','2019','1900','19/10/19','C003','2021/11/13','21/11/25');
insert into 제품모델
values('B002','M005','오븐','2019','1000','20/11/11','C003','2021/11/14','21/11/24');
insert into 제품모델
values('B002','M006','건조기','2021','1300','18/07/16','C005','2021/11/14','21/11/27');
insert into 제품모델
values('B002','M007','세탁기','2018','1600','21/01/14','C007','2021/11/14','21/11/22');
insert into 제품모델
values('B003','M008','건조기','2019','900','20/04/22','C007','2021/11/15','21/11/28');
insert into 제품모델
values('B003','M009','오븐','2021','1100','20/10/17','C008','2021/11/16','21/11/28');

insert into 렌탈정보                        
values('C009','B001','M001','2021/08/16','21/08/28','0');                        
insert into 렌탈정보                        
values('C002','B001','M002','2021/09/11','21/09/22','2');                        
insert into 렌탈정보                        
values('C001','B002','M004','2021/09/16','21/09/28','0');
insert into 렌탈정보                        
values('C005','B002','M004','2021/10/06','21/10/18','8');
insert into 렌탈정보                        
values('C009','B002','M006','2021/10/10','21/10/18','0');
insert into 렌탈정보                        
values('C003','B002','M006','2021/10/12','21/10/18','0');
insert into 렌탈정보                        
values('C002','B002','M006','2021/10/16','21/10/24','1');
insert into 렌탈정보                        
values('C008','B003','M008','2021/10/20','21/10/28','2');
insert into 렌탈정보                        
values('C004','B003','M008','2021/10/25','21/11/02','0');
insert into 렌탈정보                       
values('C003','B003','M009','2021/10/25','21/11/03','3');


-- 1 
select distinct *from 고객;
select distinct *from 직원;
select distinct *from 대리점;
select distinct *from 제품모델;
select distinct *from 렌탈정보;

-- 2 
select count(distinct 대리점ID) as 대리점수 from 대리점;

-- 3
select distinct 직원ID,직원이름,직원주소
from 직원
where 대리점ID = 'B001';

-- 4
select distinct *
from 제품모델
where 소비전력 >='1300'
ORDER BY 소비전력 desc, 출시년도 asc;

-- 5
select distinct min(제품모델.구입날짜) AS 오래된제품,대리점.대리점이름,대리점.대리점주소
from 대리점,제품모델
where 대리점.대리점ID = 제품모델.대리점ID;

-- 6
select distinct 고객.고객이름
from 고객,렌탈정보
where 고객.고객ID = 렌탈정보.고객ID  and 렌탈정보.대리점ID = 'B003';

-- 7
select distinct 고객.고객이름,대리점.대리점이름
from 고객,대리점,제품모델
where 고객.고객ID = 제품모델.고객ID and 제품모델.대리점ID = 대리점.대리점ID 
	  and 제품모델.반납예정일 - 제품모델.렌탈예정일 < '10';

-- 8
select distinct 대리점.대리점이름
from 대리점,제품모델
where 대리점.대리점ID = 제품모델.대리점ID and 제품모델.출시년도 = '2019'
group by 제품모델.대리점ID having count(*)>=2 ;

-- 렌탈정보.고객 ID
-- 9
select count(distinct 렌탈정보.모델번호) as 총제품수
from 고객,렌탈정보
where 고객.고객이름 like 'K%' and 고객.고객ID = 렌탈정보.고객ID;

-- 10
select distinct 고객.고객이름
from 고객,렌탈정보
where 고객.고객ID = 렌탈정보.고객ID  
and 렌탈정보.모델번호 in('M001','M006'); 

-- 11
select 고객ID,sum(distinct 반납연체일수) as 총반납연체일수 
from 렌탈정보
group by 고객ID;

-- 12 
select distinct 고객이름 
from 고객
where not in(select 모델번호
			from 렌탈정보
			group by 모델번호 having count(모델번호) = 0);

-- 13
select distinct 고객.고객이름,제품모델.모델번호,대리점.대리점주소
from 고객,대리점,제품모델
where 고객.고객ID = 제품모델.고객ID and 제품모델.대리점ID = 대리점.대리점ID 
	and 제품모델.렌탈예정일 >'2021-11-13' and 제품모델.반납예정일 <'2021-11-26';

-- 15
select distinct 고객.고객이름,고객.고객주소
from 고객,렌탈정보,대리점
where 고객.고객ID = 렌탈정보.고객ID and 렌탈정보.대리점ID = 대리점.대리점ID and
	  렌탈정보.반납일 < '2021-09-30' and 대리점.대리점주소 LIKE '%종로구%';

-- 16
	update 제품모델
    set 렌탈예정일 = 렌탈예정일 + 1
    where 고객ID = 'C001';


-- 17
	delete 
    from 직원
    where 대리점ID = 'B001' and 직원.직원주소 like '%마포구%';

-- 18
	create view M008렌탈고객(고객이름,고객연락처)
	as select 고객.고객이름,고객.고객연락처
		from 고객,렌탈정보
        where 고객.고객ID = 렌탈정보.고객ID and 모델번호 ='M008'
	with check option;