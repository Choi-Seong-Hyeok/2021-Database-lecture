import pymysql

def join(con,cur):
    # 입력 형식: 주고객 ID, 이름, 연락처 정보를 입력 파일로부터 읽기
    line = r_file.readline()
    line = line.strip()
    column_values = line.split()
    CID = column_values[0]
    cname = column_values[1]
    contact = column_values[2]

    global ID

    ID = CID
    # admin 때문에 고객 ID만 가변길이 5 나머지는 4

    try:
        cur.execute('insert into customer values("' + CID + '","' + cname + '","' + contact + '")')
        con.commit()
    except:
        con.rollback()

    # 출력 형식
    w_file.write("1.1. 회원가입\n")
    w_file.write("> " + CID + ' ' + cname + ' ' + contact + "\n")

def agent_info(con,cur):
    line = r_file.readline()
    line = line.strip()
    column_values = line.split()
    BID = column_values[0]
    bname = column_values[1]
    baddress = column_values[2]

    try:
        # course_sql = "insert into course values('"+cno+"', '"+cname+"', "+credit+", '"+profname+"', '"+dept+"')"
        cur.execute('insert into agent values("' + BID + '","' + bname + '","' + baddress + '")')
        con.commit()
    except:
        con.rollback()

    w_file.write("3.2. 대리점 정보 등록\n")
    w_file.write("> " + BID + ' ' + bname + ' ' + baddress + "\n")

def model_info(con,cur):
    line = r_file.readline()
    line = line.strip()
    column_values = line.split()

    BID = column_values[0]
    model_num = column_values[1]
    model_name = column_values[2]

    try:
        cur.execute('insert into model values("' + BID + '","' + model_num + '","' + model_name + '",null, null)')
        con.commit()
    except:
        con.rollback()

    w_file.write("3.3. 제품 정보 등록\n")
    w_file.write("> " + BID + ' ' + model_num + ' ' + model_name + "\n")

def agent_admin():
    line = r_file.readline()
    line = line.strip()
    column_values = line.split()
    CID = column_values[0]
    if('admin' == CID):
        w_file.write("3.1. 로그인\n")
        w_file.write("> " + CID + "\n")
    else:
        w_file.write("관리자가 아닙니다." + "\n")
def login():
    w_file.write("2.1. 로그인\n")
    w_file.write("> " + ID + "\n")

def exit():
    w_file.write("1.2. 종료\n")

def admin_logout():
    w_file.write("3.7. 로그아웃\n")
    w_file.write("> " + ID + "\n")

def model_reservation(con,cur):
    line = r_file.readline()
    line = line.strip()
    column_values = line.split()
    BID = column_values[0]
    model_num = column_values[1]
    rental_res = column_values[2]



    try:
        cur.execute("update model set rental_res = '" + rental_res +"' where model_num = '" + model_num+"'")
        con.commit()
    except:
        con.rollback()

    w_file.write("2.2. 제품 렌탈 예약\n")
    w_file.write("> " + BID + ' ' + model_num + ' ' + rental_res +"\n") # + model_name

def doTask(con,cur):
    # 종료 메뉴(1 2)가 입력되기 전까지 반복함
    while True :
        # 입력파일에서 메뉴 숫자 2개 읽기
        line = r_file.readline()
        line = line.strip()
        menu_levels = line.split()

        # 메뉴 파싱을 위한 level 구분
        menu_level_1 = int(menu_levels[0])
        menu_level_2 = int(menu_levels[1])

        # 메뉴 구분 및 해당 연산 수행
        if menu_level_1 == 1:
            if menu_level_2 == 1:
                join(con,cur)
            elif menu_level_2 == 2:
                exit()
                break

        elif menu_level_1 == 2:
            if menu_level_2 == 1:
                login()
            elif menu_level_2 == 2:
                model_reservation(con,cur)

        elif menu_level_1 == 3:
            if menu_level_2 == 1:
                agent_admin()
            elif menu_level_2 == 2:
                agent_info(con,cur)
            elif menu_level_2 == 3:
                model_info(con,cur)
            elif menu_level_2 == 7:
                admin_logout()
        else:
            break







##############
#  메인 코드  #
##############
conn = pymysql.connect(host = 'localhost',user = 'root',password = 'root',db='appliance_rental',charset = 'utf8mb4')
cursor = conn.cursor()

cursor.execute("set foreign_key_checks = 0")
cursor.execute("drop table if exists customer cascade")
cursor.execute("drop table if exists agent cascade")
cursor.execute("drop table if exists model cascade")
cursor.execute("set foreign_key_checks = 1")

cursor.execute("""create table customer(
                    CID varchar(5) not null, 
                    cname varchar(4) not null,
                    contact varchar(20),
                    primary key(CID))""")

cursor.execute("""create table agent(
                    BID char(4) not null, 
                    bname varchar(10) not null,
                    baddress varchar(20),
                    primary key(BID))""")

cursor.execute("""create table model(
                    BID char(4) not null, 
                    model_num varchar(10) not null,
                    model_name varchar(20),
                    rental_res date,
                    CID varchar(5),
                    foreign key(BID) references agent(BID) on delete cascade,
                    foreign key(CID) references customer(CID) on delete cascade,
                    primary key (BID,model_num))""")

r_file = open("input.txt", "r",encoding='UTF8')
w_file = open("output.txt", "w",encoding='UTF8')



doTask(conn,cursor)

cursor.execute("drop table if exists customer cascade")
cursor.execute("drop table if exists agent cascade")
cursor.execute("drop table if exists model cascade")
r_file.close()
w_file.close()



